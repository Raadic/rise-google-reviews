Place the following image files in this directory:

1. google-logo.png - The Google logo for the slider header
2. google-icon.png - The Google icon for the badge

You can download these images from the Google Brand Resource Center:
https://about.google/brand-resource-center/

Make sure to follow Google's brand guidelines when using their logos.
